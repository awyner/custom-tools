* Aggregate all docs and evidence on mac
* check engage.issgs.net
* To show up in upcoming/current engagements, you must be in associated cla contacts of a report (option 3)
* Can enter own ip to remove self from internal scan results
* most engagements don't have anything filled out for social engineering (separate engagement now)
* generate nessus report in html and export .nessus file
* add .nessus file to report in engage, can zip multiple .nessus files together and upload to engage all at once
* open udp ports don't get parsed into engage from .nessus, if there are open udp ports zip all nmap files together and upload to engage
* run auto merge assets if finding duplicate devices on same ip
* nikto - freq false PID, can deselect validated checkbox