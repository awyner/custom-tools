* li_at -> LinkedIn cookie, can supply to creep tool with org id to mine linkedin data
* NMLS -> nation wide certfied lenders database
* RateMyProfessor -> research higher ed