* Download bloodhound
* Download LAPS Audit
* install certipy
* 