* windows proxy autodetect - servoce that broadcasts out looking for proxy
* userid/ userawareness - probe user accounts and use user accounts within firewall policy, sends probe to each device and sees who is logged in to see which permissions to give that device on firewall, instead should be connected to active director/dc rather than scanning and probing devices
* lsass.exe -> caches credentials to log into other services
* wmiexec.py -> can be used for pass the hash attack
* powershell-empire - post-exploitation framework
* BloodHound  
* crackpkcs12  
* crowbar  
* ctf-bash-tools 
* custom-tools  
* impacket  
* kerbrute_linux_386  
* mimikatz  
* PowerSploit
* PrintSpoofer64.exe
* scopecreep
* snapback 
* hashcat                   
* john   
* SecLists               
* ipcalc                    
* neo4j-community-4.4.8                  
* gobuster-darwin-amd64                       
* nikto